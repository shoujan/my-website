<p align="center">
<img src="https://user-images.githubusercontent.com/67743899/159747006-f38ea4c4-107d-41e6-b570-1bcd9458aced.png">
</p>

#


Stuack is a chrome extension for www.studocu.com to get free premium features

## Features:
  
    -Premium banner remove
    -Blur pass
    -Documents download
    
    
    
## Documents Download:
  
    1) If document longer than 20 pages scroll down till the end of the document in order to load it (Notice if you go too fast won't load some images)
    2) Press the download button to get a document preview in another tab
    3) Press Ctrl + p in the new tab in order to print. Then select print document in pdf 



## Installation:
    
    1) Git clone or download file and unzip on a folder 
    2) Go to the extensions tab on google chrome (chrome://extensions/)
    3) Enable "Developer mode" on the top right of the tab
    4) Press on "Load unpacked" new feature that appeared on top left corner
    5) Browse the path you downloaded the extension and choose select
    6) Enjoy :)
   
  ![Installation](https://user-images.githubusercontent.com/67743899/149144506-714a84a0-cd10-4155-91fe-20c39753b578.jpg)
  
